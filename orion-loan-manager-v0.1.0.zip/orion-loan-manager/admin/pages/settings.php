<?php
if (!defined('ABSPATH')) exit;
?>
<div class="wrap">
  <h1>Settings</h1>
  <p>This minimal v0.1 has no global settings yet. All business rules follow the Orion spec (interest accrues monthly on full outstanding; minimum payment check with grace; penalty once per cycle; no capitalization; oldest-charge-first payment allocation).</p>
</div>
